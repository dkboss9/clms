require('bootstrap/js/dist/tooltip');

// jsTree - is jquery plugin, that provides interactive trees: https://www.jstree.com/
require('jstree/dist/jstree.js');

require('./jstree.scss');
